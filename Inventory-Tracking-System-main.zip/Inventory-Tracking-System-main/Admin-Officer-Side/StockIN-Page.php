<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock In Page</title>
    <link rel="stylesheet" href="../styles/StockIn-Page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
</head>

<body>
    <header>
        <div class="image-logo">
            <span class="bsulogo">
                <img src="../images/BatStateU-Logo.png" alt="logo">
            </span>
            <div class="outside-content">
                <span class="title">RESOURCE GENERATION OFFICE</span>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="first-col">
            <i class="unif-note">Please select the product you want to add stocks.</i>
            <div class="unif-header">MEN'S UNIFORM</div>
            <div class="men" style="display: flex; flex-direction: row;">
                <div>
                    <span class="image">
                        <img src="../images/Polo-Image.jpg" alt="" style="height: 150px; width: 150px;" data-product-id="1">
                    </span>
                    <p class="unif-name">Polo</p>
                </div>
                <div>
                    <span class="image">
                        <img src="../images/Pants-Image.png" alt="" style="height: 150px; width: 150px;">
                    </span>
                    <p class="unif-name">Pants</p>
                </div>
            </div>
            <div class="unif-header">WOMEN'S UNIFORM</div>
            <div class="women" style="display: flex; flex-direction: row;">
                <div>
                    <span class="image">
                        <img src="../images/Blouse-Image.jpg" alt="" style="height: 150px; width: 150px;">
                    </span>
                    <p class="unif-name">Blouse</p>
                </div>
                <div>
                    <span class="image">
                        <img src="../images/Skirt-Image.jpg" alt="" style="height: 150px; width: 150px;">
                    </span>
                    <p class="unif-name">Skirt</p>
                </div>
            </div>
            <div class="unif-header">PE UNIFORM</div>
            <div class="pe" style="display: flex; flex-direction: row;">
                <div>
                    <span class="image">
                        <img src="../images/PE-Shirt-Image.png" alt="" style="height: 150px; width: 150px;">
                    </span>
                    <p class="unif-name">PE Shirt</p>
                </div>
                <div>
                    <span class="image">
                        <img src="../images/PE-Pants-Image.png" alt="" style="height: 150px; width: 150px;">
                    </span>
                    <p class="unif-name">PE Pants</p>
                </div>
            </div>
        </div>

        <div class="second-col">
            <div class="forspartan" style="margin-top: 10px;">
                <div class="spartanlogo">
                    <img src="../images/RedSpartan-Logo.png" alt="logo" style="height: 570px; width: auto;">
                </div>
            </div>
            <div class="text-container" style="margin-left: 20px; color: rgb(32, 28, 28);">
                <div class="text">
                    This page is exclusively designated for officers
                </div>
                <div class="textr" style="margin-left: 18px">
                    responsible for adding stock of products.
                </div>
            </div>
        </div>

        <div class="third-col">
            <form id="productForm" action="../PHP-Scripts/stocksIn.php" method="post">
                <div class="stock-title">Stock In</div>
                <div class="form-group">
                    <div class="form-group">
                        <i class="bx bxl-product-hunt" aria-hidden="true"></i>
                        <input type="text" name="employeeId" placeholder="Employee ID"
                            style="width: 250px; height: 45px;">
                    </div>
                    <div class="form-group">
                        <i class="bx bxl-product-hunt" aria-hidden="true"></i>
                        <input type="text" name="productId" placeholder="Product ID"
                            style="width: 250px; height: 45px;">
                    </div>
                    <div class="form-group">
                        <i class="bx bxl-product-hunt" aria-hidden="true"></i>
                        <input type="text" name="description" placeholder="Description"
                            style="width: 250px; height: 45px;">
                    </div>
                    <div class="form-group">
                        <i class="bx bx-list-ol" aria-hidden="true"></i>
                        <select name="size" style="width: 250px; height: 48px;">
                            <option value="small">Small</option>
                            <option value="medium">Medium</option>
                            <option value="large">Large</option>
                            <option value="xl">XL</option>
                            <option value="2xl">2XL</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <i class="bx bx-list-ol" aria-hidden="true"></i>
                        <input type="number" name="quantityin" placeholder="Quantity"
                            style="width: 250px; height: 45px;">
                    </div>
                    
                    <button class="update-button" type="submit" name="submit"
                        style="margin-top: 30px; padding: 10px 60px;">Add Stocks</button>
                </div>
            </form>
            <i>Note: Please incorporate the precise stock.</i>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script>
        $(document).ready(function() {
            $(".image").click(function() {
                // Get product name from the clicked image's sibling description
                var productName = $(this).siblings('.unif-name').text();

                // Set the value of the Product Name input field
                $(".third-col input[name='description']").val(productName).css({
                    'color': 'Black',
                    'font-weight': 'bold'
                }).prop('readonly', true);

                // Fetch the actual Product ID from the server using AJAX
                $.ajax({
                    type: "POST",
                    url: "../PHP-Scripts/checkProductExistence.php", // Replace with the correct path to your PHP file
                    data: {
                        productName: productName
                    },
                    success: function(data) {
                        // Set the fetched Product ID to the input field
                        $(".third-col input[name='productId']").val(data);
                    },
                    error: function() {
                        // Handle errors if needed
                        alert("Error fetching Product ID from the server");
                    }
                });

                $(".second-col").hide();
                $(".third-col").show();
            });
        });


        document.getElementById('productForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the form from submitting normally

            // Get the form data
            var formData = new FormData(this);

            // Use fetch to submit the form data to the server
            fetch('../PHP-Scripts/stockIn.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    // Check the response and show SweetAlert accordingly
                    if (data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Stock Sucessfully Added!',
                            text: data.message,
                        }).then((result) => {
                            // Redirect to the same page after the user clicks OK
                            if (result.isConfirmed) {
                                window.location.href = window.location.href;
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: data.message,
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'An unexpected error occurred. Please try again later.',
                    });
                });
        });
        </script>

</body>

</html>