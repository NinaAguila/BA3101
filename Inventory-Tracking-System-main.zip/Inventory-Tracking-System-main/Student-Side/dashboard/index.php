<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Side Menu Bar</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
    <link rel="stylesheet" href="style.css" />
    <style>
        <?php
        // Import Google Fonts using PHP
        echo '@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap");';
        ?>
    
        
        * {
            margin: 0;
            padding: 0;
            outline: none;
            border: none;
            text-decoration: none;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            background: #dfe9f5;
        }

        nav {
            position: absolute;
            top: 0;
            bottom: 0;
            height: 100%;
            left: 0;
            background: #fff;
            width: 90px;
            overflow: hidden;
            transition: width 0.2s linear;
            box-shadow: 0 20px 35px rgba(0, 0, 0, 0.1);
        }

        .nav-expanded {
            height: 89px; /* Adjust the height as needed */
        }


        .logo {
            text-align: center;
            display: flex;
            transform: all 0.5s ease;
            margin: 0 0 0 10px;
            padding: 5px;
        }

        .logo img {
            width: 65px;
            height: 60px;
            border-radius: 50%;
        }

        .logo span {
            font-weight: bold;
            padding-left: 0px;
            font-size: 15px;
            text-transform: uppercase;
        }

        a {
            position: relative;
            color: rgb(85, 83, 83);
            font-size: 14px;
            display: table;
            width: 300px;
            padding: 10px;
        }

        .fas {
            position: relative;
            width: 70px;
            height: 40px;
            top: 10px;
            font-size: 20px;
            text-align: center;
        }

        .nav-item {
            position: relative;
            top: 10px;
            margin-left: 10px;
        }

        a:hover {
            background: #ff4141;
        }

        nav:hover {
            width: 300px;
            transition: all 0.5s ease;
        }
    </style>
</head>

<script>
    $(document).ready(function() {
        var nav = $('nav');
        var navHeight = 10; // Adjust the initial height of the navigation bar

        $(window).scroll(function() {
            if ($(this).scrollTop() > navHeight) {
                nav.addClass('nav-expanded');
            } else {
                nav.removeClass('nav-expanded');
            }
        });
    });
</script>

<body>
<nav>
    <div>
        <ul>
            <li><a href="dashboard.php" class="logo"><img src="bsulogointro.png" alt=""><span class="nav-item">Resource Generation Office</span></a></li>
            <li><a href="mens.php"><i class="fas fa-male"></i><span class="nav-item">Mens Uniform</span></a></li>
            <li><a href="womens.php"><i class="fas fa-female"></i><span class="nav-item">Womens Uniform</span></a></li>
            <li><a href="PE.php"><i class="fas fa-futbol"></i><span class="nav-item">PE Uniform</span></a></li>
        </ul>
    </div>
</nav>
</body>
</html>
