<?php
require_once('index.php');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_ba3101";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function fetchDataBySize($conn, $product_id) {
    $sqlStockIn = "SELECT productSize, quantityIn FROM tbl_stockin WHERE productID = '$product_id'";
    $sqlStockOut = "SELECT productSize, quantityOut FROM tbl_stockout WHERE productID = '$product_id'";

    $resultStockIn = $conn->query($sqlStockIn);
    $resultStockOut = $conn->query($sqlStockOut);

    $sizeQuantity = ['small' => 0, 'medium' => 0, 'large' => 0, 'xl' => 0, '2xl' => 0];

    while ($row = $resultStockIn->fetch_assoc()) {
        $size = $row["productSize"];
        $quantity = $row["quantityIn"];

        if (array_key_exists($size, $sizeQuantity)) {
            $sizeQuantity[$size] += $quantity;
        }
    }

    while ($row = $resultStockOut->fetch_assoc()) {
        $size = $row["productSize"];
        $quantity = $row["quantityOut"];

        if (array_key_exists($size, $sizeQuantity)) {
            $sizeQuantity[$size] -= $quantity;
        }
    }

    return $sizeQuantity;
}

$product_id_Blouse = "2";
$sizeCountBlouse = fetchDataBySize($conn, $product_id_Blouse);

$product_id_Skirt = "5";
$sizeCountSkirt = fetchDataBySize($conn, $product_id_Skirt);

$conn->close();
?>



<!DOCTYPE html>
<html>
<head>
  <style>
  .header {
    background-color: #991828; /* Dark background color */
    color: white; /* Text color */
    padding: 10px;
    text-align: center;
    font-size: 15px; /* Increase font size */
  }
    body {
        background-image: url("dash_bg.jpg");
        background-size: cover;
        background-repeat: no-repeat;
        background-position: inherit;
        margin: 0; /* Remove default margin */
    }
    .container-wrapper {
      display: flex;
      justify-content: space-between; /* Distribute space between the containers */
      align-items: center;
      padding: 20px; /* Add padding for spacing */
    }

    .container {
      display: flex;
      flex-direction: column;
      position: relative;
      width: 290px;
      height: 390px;
    }
    .image-container {
      width: 90%;
      height: 100%;
      overflow: visible;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Add box shadow to the image container */
    }
    .image {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 10px;
    }

    .content {
      text-align: center;
    }

    .row-text-container {
      display: flex;
      justify-content: space-between;
      padding: 10px;
    }

    .row {
      flex: 1;
    }

    .text-box {
      flex: 1;
      background-color: #eee;
      padding: 10px;
    }
    .red-text {
      color: red;
    } 
    /* Additional styling for the small containers on both sides */
    .small-container {
      margin: 100px;
      width: 235px;
      height: 235px; /* Adjust the height as needed */
      background-color: #eee;
      padding: 10px; /* Adjust padding as needed */
      text-align: center;
      border-radius: 10px;
    }

    /* Additional styling for the text inside the small containers */
    .small-container p {
      font-size: 12px; /* Adjust font size as needed */
      line-height: 1.5; /* Adjust line height as needed */
    }
  </style>
</head>

<body>
  <div class="header">
    <h1>Womens Uniform</h1>
    <p>Welcome to the Womens Uniform page. Check out the available stocks below.</p>
  </div>

  <div class="container-wrapper">
    <!-- Small container on the left side -->
    <div class="small-container">
    <p>This is the blouse for Womens Uniform. You can see under the image the different sizes. You will be guided by the shoulder width sizes below: (inches)</p><br>
    <p><b>S</b> 16.0 <br> <b>M</b> 17.5 <br> <b>L</b> 18.5 <br> <b>XL</b> 19.0 <br> <b>XXL</b> 20.0</p>
    </div>

    <!-- Container for blouse data -->
<div class="container">
  <div class="image-container">
    <img src="blouse1.jpg" alt="Blouse Image" class="image">
  </div>
  <?php
  foreach ($sizeCountBlouse as $size => $count) {
      echo '<div class="row-text-container">';
      echo '<div class="row">' . $size . '</div>';
      // Check if count is 0 and apply red color to the text
      echo '<div class="text-box' . ($count == 0 ? ' red-text' : '') . '">' . $count . '</div>';
      echo '</div>';
  }
  ?>
</div>

<!-- Container for skirts data -->
<div class="container">
  <div class="image-container">
    <img src="skirts1.jpg" alt="Skirt Image" class="image">
  </div>
  <?php
  foreach ($sizeCountSkirt as $size => $count) {
      echo '<div class="row-text-container">';
      echo '<div class="row">' . $size . '</div>';
      // Check if count is 0 and apply red color to the text
      echo '<div class="text-box' . ($count == 0 ? ' red-text' : '') . '">' . $count . '</div>';
      echo '</div>';
  }
  ?>
</div>


    <!-- Small container on the right side -->
    <div class="small-container">
      <p>This is the skirts for Womens Uniform. You can see under the image the different sizes. You will be guided by the waistline sizes below: (inches)</p><br>
      <p><b>S</b> 28-30 <br> <b>M</b> 30-32 <br> <b>L</b> 32-34 <br> <b>XL</b> 34-37 <br> <b>XXL</b> 48-41</p>
      <!-- Add your content here -->
    </div>
  </div>
</body>
</html>
