<?php require_once('index.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" />
</head>

<style>
    body {
    background-image: url("dash_bg.jpg");
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    margin: 0; /* Remove default margin */
}

.dashboard_content {
    margin-top: 20%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
}

.dashboard_content h1 {
    font-size: 50px;
    color: #333;
}

.dashboard_content p {
    font-size: 20px;
    color: #666;
}

.icons-socials {
    display: flex;
    justify-content: center;
    align-items: flex-start; /* Align to the top */
    margin-top: 20px;
}

.icons-socials a {
    margin: 0 10px;
    text-decoration: none;
    color: blue;
    padding-top: 5px;

}

.icons-socials i {
    font-size: 20px;
    position: relative;
}
.visit{
    font-size: 15px;
    margin-bottom: 5px;
    color: blue;
}
    
</style>

<body>
    <div class="dashboard_content">
        <h1>Welcome to Resource Generation Office</h1>
        <p>View all the Uniform Stocks here</p>
    </div>

    <div class="icons-socials">
        <a href="https://www.facebook.com/BatStateULipaRGO" target="_blank"><i class="bx bxl-facebook-circle"></i><span class="visit"> Visit us here in our facebook page</span></a>
</body>

</html>