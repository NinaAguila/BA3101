<?php
require "dbConnection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employeeID = $_POST['employeeId'];
    $productID = $_POST['productId'];
    $productSize = $_POST['size'];
    $quantityOut = $_POST['quantityin'];


    // Check if the product ID exists in another table (e.g., tbl_products)
    $checkProductSql = "SELECT * FROM tbl_products WHERE productID = ?";
    $checkProductStmt = $conn->prepare($checkProductSql);

    if ($checkProductStmt) {
        $checkProductStmt->bind_param("s", $productID);
        $checkProductStmt->execute();
        $checkProductResult = $checkProductStmt->get_result();

        if ($checkProductResult->num_rows > 0) {
            // Product ID exists, proceed with the insert

            // You may choose to insert a new record if none exists
            $insertSql = "INSERT INTO tbl_stockin (employeeID, productID, productSize, quantityIn) VALUES (?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertSql);

            if ($insertStmt) {
                // Bind parameters for insert
                $insertStmt->bind_param("sssi", $employeeID, $productID, $productSize, $quantityOut);

                // Execute the insert statement
                if ($insertStmt->execute()) {
                    $response = array("success" => true, "message" => "New record inserted successfully!");
                } else {
                    $response = array("success" => false, "message" => "Error inserting a new record: " . $insertStmt->error);
                }

                $insertStmt->close();
            } else {
                $response = array("success" => false, "message" => "Error in prepare for insert: " . $conn->error);
            }
        } else {
            // Product ID does not exist in the tbl_products table
            $response = array("success" => false, "message" => "Product ID does not exist.");
        }

        $checkProductStmt->close();
    } else {
        $response = array("success" => false, "message" => "Error in prepare: " . $conn->error);
    }

    // Send a JSON response
    echo json_encode($response);
}

$conn->close();
