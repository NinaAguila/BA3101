<?php
require "dbConnection.php";

// Check if the "productName" key exists in the POST request
if (isset($_POST['productName'])) {
    // Get the product name from the POST request and convert it to lowercase
    $productName = strtolower($_POST['productName']);

    // Prepare and execute the query
    $stmt = $conn->prepare("SELECT productID FROM tbl_products WHERE LOWER(productName) = ?");
    $stmt->bind_param("s", $productName);
    $stmt->execute();
    $stmt->bind_result($fetchedProductId);

    // Fetch the result
    $stmt->fetch();

    // Close the connection and statement
    $stmt->close();
    $conn->close();

    // Check if a matching product ID was found
    if (!empty($fetchedProductId)) {
        // Return the fetched product ID
        echo $fetchedProductId;
    } else {
        // If no matching product ID is found, handle the error
        echo "Error: No matching product ID found for the given product name.";
    }
} else {
    echo "Error: Product name not provided in the request.";
}

?>
