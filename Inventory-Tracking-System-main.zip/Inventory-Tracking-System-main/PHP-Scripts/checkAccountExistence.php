<?php
require "dbConnection.php";

// Get the data from the request
$data = json_decode(file_get_contents("php://input"));

// Extract email from the data
$employeeID = $data->employeeID;
$employeeEmail = $data->employeeEmail;

// SQL query to check if the account exists
$sql = "SELECT * FROM tbl_employeeaccount WHERE employeeID = '$employeeID' OR employeeEmail = '$employeeEmail'";

$result = $conn->query($sql);

// Check if the account exists
if ($result->num_rows > 0) {
    // Account exists
    $response = array("exists" => true);
} else {
    // Account does not exist
    $response = array("exists" => false);
}

// Send the JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn->close();
?>
